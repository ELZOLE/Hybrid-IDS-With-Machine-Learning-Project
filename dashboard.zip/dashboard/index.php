<?php include 'api/auth_check.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>IDS Dashboard - Overview</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
</head>
<body>
    <aside class="sidebar">
        <h1>IDS</h1>
        <nav>
            <a href="index.php" class="active">Overview</a>
            <a href="alerts.php">Alert ML</a>
            <a href="snort_alerts.php">Alert Snort</a>
            <a href="rules.php">Rules</a>
            <a href="#" id="logout-btn" style="margin-top: 20px;">Logout</a>
        </nav>
    </aside>

    <main class="content">
        <div class="main-header">
            <h1>Dashboard Overview</h1>
            <button id="download-pdf-btn">Download Report (PDF)</button>
        </div>

        <div class="stats-container">
            <div class="card stat-card">
                <h2 id="stat-total-alerts">0</h2>
                <p>Total Alerts</p>
            </div>
            <div class="card stat-card">
                <h2 id="stat-unique-attackers">0</h2>
                <p>Unique Attackers</p>
            </div>
        </div>

        <div class="chart-container" id="report-charts-row1">
            <div class="chart-wrapper card">
                <h2>Daily Activity (Last 7 Days)</h2>
                <canvas id="dailyActivityChart"></canvas>
            </div>
            <div class="chart-wrapper donut card">
                <h2>Alert Source Proportions</h2>
                <canvas id="typeDonutChart"></canvas>
            </div>
        </div>

        <div class="chart-container" id="report-charts-row2">
            <div class="chart-wrapper card">
                <h2>Top 5 Alert Types (by Count)</h2>
                <canvas id="topTypesBarChart"></canvas>
            </div>
            <div class="chart-wrapper donut card">
                <h2>Alert Type Distribution</h2>
                <canvas id="alertTypesChart"></canvas>
            </div>
        </div>

        <div class="card" id="report-table">
            <h2>Top 10 Attackers</h2>
            <table>
                <thead>
                    <tr>
                        <th>Source IP</th>
                        <th>Total Attacks</th>
                        <th>ML Events</th>
                        <th>Snort Events</th>
                    </tr>
                </thead>
                <tbody id="attackers-table-body"></tbody>
            </table>
        </div>
    </main>

    <script src="js/overview.js"></script>

    <script>
    document.getElementById('logout-btn').addEventListener('click', function(e) {
        e.preventDefault(); // Prevent the link from navigating immediately
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to log out?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'api/logout.php'; // Redirect to logout script if confirmed
            }
        });
    });
    </script>
</body>
</html>
