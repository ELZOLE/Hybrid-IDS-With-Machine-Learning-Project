document.addEventListener('DOMContentLoaded', function() {
    // Fetch for Stat Cards
    fetch('api/get_stats.php')
        .then(response => response.json())
        .then(stats => {
            document.getElementById('stat-total-alerts').innerText = stats.total_alerts.toLocaleString();
            document.getElementById('stat-unique-attackers').innerText = stats.unique_attackers.toLocaleString();
        });

    // Fetch for Alert Source Proportions Donut (Top Right)
    fetch('api/get_summary.php')
        .then(response => response.json())
        .then(summary => {
            const donutCtx = document.getElementById('typeDonutChart').getContext('2d');
            new Chart(donutCtx, {
                type: 'doughnut',
                plugins: [ChartDataLabels],
                data: {
                    labels: ['Alert ML', 'Alert Snort'],
                    datasets: [{
                        data: [summary.ml_total, summary.snort_total],
                        backgroundColor: ['#3b82f6', '#10b981']
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false,
                    plugins: { 
                        legend: { position: 'bottom' },
                        datalabels: {
                            formatter: (value, ctx) => {
                                let sum = ctx.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                                let percentage = (value * 100 / sum);
                                return percentage > 1 ? percentage.toFixed(1) + '%' : '';
                            },
                            color: '#fff',
                            font: { weight: 'bold' }
                        }
                    }
                }
            });
        });
    
    // Fetch for Daily Activity Chart (Top Left)
    fetch('api/get_daily_activity.php')
        .then(response => response.json())
        .then(data => {
            const dailyCtx = document.getElementById('dailyActivityChart').getContext('2d');
            new Chart(dailyCtx, {
                type: 'bar',
                plugins: [ChartDataLabels],
                data: {
                    labels: data.labels,
                    datasets: [
                        { label: 'Alert ML', data: data.ml_data, backgroundColor: '#3b82f6' },
                        { label: 'Alert Snort', data: data.snort_data, backgroundColor: '#10b981' }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: { 
                        y: { 
                            beginAtZero: true,
                            grace: '10%'
                        }, 
                        x: { stacked: false } 
                    },
                    plugins: { 
                        datalabels: {
                            display: true,
                            anchor: 'end',
                            align: 'end',
                            color: '#64748b',
                            font: { weight: 'bold', size: 10 },
                            formatter: (value) => value > 0 ? value : ''
                        }
                    }
                }
            });
        });

    // ? Fixed: Fetch for Top 5 Alert Types Horizontal Bar Chart (Bottom Left)
    fetch('api/get_top_5_types_bar.php')
        .then(response => response.json())
        .then(data => {
            const barCtx = document.getElementById('topTypesBarChart').getContext('2d');
            new Chart(barCtx, {
                type: 'bar',
                plugins: [ChartDataLabels],
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Total Count',
                        data: data.data,
                        backgroundColor: '#8b5cf6'
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: { 
                        x: { 
                            type: 'linear',
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return value.toLocaleString();
                                }
                            }
                        },
                        y: {
                            ticks: {
                                autoSkip: false,
                                font: { weight: 'bold' }
                            }
                        }
                    },
                    plugins: {
                        legend: { display: false },
                        datalabels: {
                            anchor: 'end',
                            align: 'end',
                            color: '#475569',
                            font: { weight: 'bold' }
                        }
                    }
                }
            });
        });

    // Fetch for Alert Type Distribution Donut (Bottom Right)
    fetch('api/get_alert_types.php')
        .then(response => response.json())
        .then(data => {
            const typesCtx = document.getElementById('alertTypesChart').getContext('2d');
            new Chart(typesCtx, {
                type: 'doughnut',
                plugins: [ChartDataLabels],
                data: {
                    labels: data.labels,
                    datasets: [{
                        data: data.data,
                        backgroundColor: ['#ef4444', '#f97316', '#eab308', '#22c55e', '#0ea5e9', '#64748b']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom' },
                        datalabels: {
                            formatter: (value, ctx) => {
                                let sum = ctx.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                                let percentage = (value * 100 / sum);
                                return percentage > 3 ? percentage.toFixed(1) + '%' : '';
                            },
                            color: '#fff',
                            font: { weight: 'bold' }
                        }
                    }
                }
            });
        });

    // Fetch for Top Attackers Table
    fetch('api/get_top_attackers.php')
        .then(response => response.json())
        .then(attackers => {
            if (!Array.isArray(attackers)) return;
            const tableBody = document.getElementById('attackers-table-body');
            tableBody.innerHTML = '';
            attackers.forEach(attacker => {
                tableBody.innerHTML += `
                    <tr>
                        <td>${attacker.ip}</td>
                        <td>${attacker.total_count}</td>
                        <td>${attacker.ml_count}</td>
                        <td>${attacker.snort_count}</td>
                    </tr>
                `;
            });
        });

    // PDF Report Functionality
    document.getElementById('download-pdf-btn').addEventListener('click', generateFullReport);

    async function generateFullReport() {
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF('p', 'pt', 'a4');

        const [ mlAlertsResponse, snortAlertsResponse, rulesResponse ] = await Promise.all([
            fetch('api/get_ml_alerts_summary.php?all=true'),
            fetch('api/get_snort_alerts.php?all=true'),
            fetch('api/get_rules.php?all=true')
        ]);

        const mlAlerts = await mlAlertsResponse.json();
        const snortAlerts = await snortAlertsResponse.json();
        const rules = await rulesResponse.json();

        pdf.setFontSize(20).text("IDS Dashboard - Full Report", 40, 40);
        pdf.setFontSize(12).text(`Report Generated: ${new Date().toLocaleString()}`, 40, 60);

        const chartsRow1 = document.getElementById('report-charts-row1');
        const chartsRow2 = document.getElementById('report-charts-row2');
        
        const canvas1 = await html2canvas(chartsRow1);
        const canvas2 = await html2canvas(chartsRow2);

        const imgWidth = 515;
        const img1Height = (canvas1.height * imgWidth) / canvas1.width;
        const img2Height = (canvas2.height * imgWidth) / canvas2.width;

        pdf.addImage(canvas1.toDataURL('image/png'), 'PNG', 40, 100, imgWidth, img1Height);
        pdf.addImage(canvas2.toDataURL('image/png'), 'PNG', 40, 100 + img1Height + 10, imgWidth, img2Height);
        
        pdf.autoTable({
            startY: 100 + img1Height + img2Height + 20,
            head: [['Source IP', 'Total Attacks', 'ML Events', 'Snort Events']],
            body: Array.from(document.getElementById('attackers-table-body').rows).map(row =>
                [row.cells[0].innerText, row.cells[1].innerText, row.cells[2].innerText, row.cells[3].innerText]
            ),
        });

        pdf.addPage();
        pdf.setFontSize(16).text("Machine Learning Alerts", 40, 40);
        pdf.autoTable({
            startY: 60,
            head: [['Start Time', 'End Time', 'Source IP', 'Destination IP', 'Category', 'Message', 'Count']],
            body: mlAlerts.sessions.map(item => [item.start_time, item.end_time, item.source_ip, item.destination_ip, item.category, item.message, item.event_count]),
        });

        pdf.addPage();
        pdf.setFontSize(16).text("Snort Alerts", 40, 40);
        pdf.autoTable({
            startY: 60,
            head: [['Start Time', 'End Time', 'ID', 'Source IP', 'Destination IP', 'Message', 'Count']],
            body: snortAlerts.sessions.map(item => [item.start_time, item.end_time, item.signature, item.source_ip, item.destination_ip, item.message, item.event_count]),
        });

        pdf.addPage();
        pdf.setFontSize(16).text("Snort Rules", 40, 40);
        pdf.autoTable({
            startY: 60,
            head: [['SID', 'Protocol', 'Source', 'Destination', 'Action', 'Message']],
            body: rules.rules.map(item => [item.SID, item.PROTOCOL, `${item['SOURCE IP']}:${item['SOURCE PORT']}`, `${item['DESTINATION IP']}:${item['DEST. PORT']}`, item.ACTION, item.MESSAGE]),
        });
        
        pdf.save('IDS-Dashboard-Report.pdf');
    }
});
