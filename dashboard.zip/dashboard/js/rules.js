document.addEventListener('DOMContentLoaded', function() {
    let currentPage = 1;
    const rowsPerPage = 10;
    let allRules = [];
    let blockedIps = [];

    // --- Function to send block/unblock request ---
    async function requestIpAction(ip, action) {
        try {
            const response = await fetch('api/block_manager.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ip, action })
            });
            const result = await response.json();
            
            // --- UPDATED to SweetAlert2 ---
            if (result.status === 'success') {
                Swal.fire({
                    title: 'Request Sent!',
                    text: `The request to ${action} ${ip} is being processed.`,
                    icon: 'success',
                    timer: 2000,
                    showConfirmButton: false
                });
                setTimeout(fetchData, 1000); // Refresh data
            } else {
                Swal.fire({
                    title: 'Error!',
                    text: `An error occurred: ${result.message}`,
                    icon: 'error'
                });
            }
        } catch (error) {
            console.error('Error requesting IP action:', error);
            Swal.fire({
                title: 'Request Failed',
                text: 'Could not connect to the server. Please check the console.',
                icon: 'error'
            });
        }
    }

    function renderTable() {
        const tableBody = document.getElementById('rules-table-body');
        tableBody.innerHTML = '';
        const start = (currentPage - 1) * rowsPerPage;
        const end = start + rowsPerPage;
        const paginatedRules = allRules.slice(start, end);

        paginatedRules.forEach(rule => {
            const sourceIp = rule['SOURCE IP'];
            const canBeBlocked = sourceIp && sourceIp !== 'any' && sourceIp.match(/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/);
            const isBlocked = blockedIps.includes(sourceIp);
            
            let actionButtonHtml = '';
            if (canBeBlocked) {
                const btnClass = isBlocked ? 'btn-unblock' : 'btn-block';
                const btnText = isBlocked ? 'Unblock' : 'Block';
                const btnAction = isBlocked ? 'unblock' : 'block';
                actionButtonHtml = `<button class="action-btn ${btnClass}" data-ip="${sourceIp}" data-action="${btnAction}">${btnText}</button>`;
            }

            tableBody.innerHTML += `
                <tr>
                    <td>${rule.SID || ''}</td>
                    <td>${rule.PROTOCOL || ''}</td>
                    <td>${rule['SOURCE IP'] || ''}</td>
                    <td>${rule['SOURCE PORT'] || ''}</td>
                    <td>${rule.DIRECTION || '->'}</td>
                    <td>${rule['DESTINATION IP'] || ''}</td>
                    <td>${rule['DEST. PORT'] || ''}</td>
                    <td>${rule.ACTION || ''}</td>
                    <td>${rule.MESSAGE || ''}</td>
                    <td>${rule.STATUS || 'Active'}</td>
                    <td>${actionButtonHtml}</td>
                </tr>
            `;
        });
    }

    function renderPagination() {
        const paginationControls = document.getElementById('pagination-controls');
        if (!paginationControls) return;
        paginationControls.innerHTML = '';
        const pageCount = Math.ceil(allRules.length / rowsPerPage);

        if (pageCount <= 1) return; // Don't show controls if only one page

        const prevButton = document.createElement('button');
        prevButton.innerText = 'Previous';
        prevButton.disabled = currentPage === 1;
        prevButton.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
                renderPagination();
            }
        });
        paginationControls.appendChild(prevButton);

        const pageInfo = document.createElement('span');
        pageInfo.innerText = `Page ${currentPage} of ${pageCount}`;
        paginationControls.appendChild(pageInfo);

        const nextButton = document.createElement('button');
        nextButton.innerText = 'Next';
        nextButton.disabled = currentPage === pageCount;
        nextButton.addEventListener('click', () => {
            if (currentPage < pageCount) {
                currentPage++;
                renderTable();
                renderPagination();
            }
        });
        paginationControls.appendChild(nextButton);
    }

    // --- Add event listener for block/unblock buttons ---
    document.getElementById('rules-table-body').addEventListener('click', function(e) {
        if (e.target && e.target.matches('button.action-btn')) {
            const ip = e.target.dataset.ip;
            const action = e.target.dataset.action;
            if (ip && action) {
                // --- UPDATED to SweetAlert2 ---
                Swal.fire({
                    title: 'Are you sure?',
                    text: `Do you want to ${action} the IP address ${ip}?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `Yes, ${action} it!`,
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        requestIpAction(ip, action);
                    }
                });
            }
        }
    });

    // --- Fetch both rules and blocked IPs ---
    async function fetchData() {
        try {
            const [rulesResponse, blockedResponse] = await Promise.all([
                fetch('api/get_rules.php?all=true'),
                fetch('api/block_manager.php?action=get_status')
            ]);
            
            const rulesData = await rulesResponse.json();
            const blockedData = await blockedResponse.json();

            allRules = rulesData.rules || [];
            blockedIps = blockedData.blocked_ips || [];
            
            currentPage = 1;
            renderTable();
            renderPagination();
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }

    fetchData();
});
