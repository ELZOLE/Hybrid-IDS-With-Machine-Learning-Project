document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.getElementById('ml-alerts-table');
    const paginationControls = document.getElementById('pagination-controls');
    let currentPage = 1;

    function fetchSummary(page) {
        fetch(`api/get_ml_alerts_summary.php?page=${page}`)
            .then(response => response.json())
            .then(data => {
                tableBody.innerHTML = '';

                data.sessions.forEach(session => {
                    tableBody.innerHTML += `
                        <tr>
                            <td>${session.start_time}</td>
                            <td>${session.end_time}</td>
                            <td>${session.source_ip}</td>
                            <td>${session.destination_ip}</td>
                            <td>${session.category}</td>
                            <td>${session.message}</td>
                            <td>${session.event_count}</td>
                        </tr>
                    `;
                });

                currentPage = data.current_page;
                renderPagination(data.total_pages);
            })
            .catch(error => console.error('Error fetching ML alerts summary:', error));
    }

    function renderPagination(totalPages) {
        paginationControls.innerHTML = '';

        const prevButton = document.createElement('button');
        prevButton.textContent = 'Previous';
        prevButton.disabled = currentPage === 1;
        prevButton.onclick = () => {
            if (currentPage > 1) {
                fetchSummary(currentPage - 1);
            }
        };
        paginationControls.appendChild(prevButton);

        const pageInfo = document.createElement('span');
        pageInfo.textContent = ` Page ${currentPage} of ${totalPages} `;
        pageInfo.style.margin = '0 15px';
        paginationControls.appendChild(pageInfo);

        const nextButton = document.createElement('button');
        nextButton.textContent = 'Next';
        nextButton.disabled = currentPage === totalPages;
        nextButton.onclick = () => {
            if (currentPage < totalPages) {
                fetchSummary(currentPage + 1);
            }
        };
        paginationControls.appendChild(nextButton);
    }

    fetchSummary(1);
});
