<?php
$mlLogPath = '../data/alerts.jsonl';
$snortLogPath = '../data/alert';

$ml_daily_counts = [];
$snort_daily_counts = [];
$all_dates = [];

// Process ML Logs
if (file_exists($mlLogPath)) {
    $handle = fopen($mlLogPath, 'r');
    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $log = json_decode(trim($line), true);
            if (is_array($log) && isset($log['timestamp'])) {
                $date = date('Y-m-d', strtotime($log['timestamp']));
                $all_dates[$date] = true;
                if (!isset($ml_daily_counts[$date])) $ml_daily_counts[$date] = 0;
                $ml_daily_counts[$date]++;
            }
        }
        fclose($handle);
    }
}

// Process Snort Logs
if (file_exists($snortLogPath)) {
    $lines = file($snortLogPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (preg_match('/^(\d{2}\/\d{2}-\d{2}:\d{2}:\d{2})/', $line, $matches)) {
            $timestamp_str = date("Y")."/".str_replace("-", " ", $matches[1]);
            $date = date('Y-m-d', strtotime($timestamp_str));
            $all_dates[$date] = true;
            if (!isset($snort_daily_counts[$date])) $snort_daily_counts[$date] = 0;
            $snort_daily_counts[$date]++;
        }
    }
}

// Prepare data for the last 7 active days
$sorted_dates = array_keys($all_dates);
sort($sorted_dates);
$last_7_dates = array_slice($sorted_dates, -7);

$labels = [];
$ml_data = [];
$snort_data = [];

foreach ($last_7_dates as $date) {
    $labels[] = $date;
    $ml_data[] = $ml_daily_counts[$date] ?? 0;
    $snort_data[] = $snort_daily_counts[$date] ?? 0;
}

$result = [
    'labels' => $labels,
    'ml_data' => $ml_data,
    'snort_data' => $snort_data
];

header('Content-Type: application/json');
echo json_encode($result);
?>
