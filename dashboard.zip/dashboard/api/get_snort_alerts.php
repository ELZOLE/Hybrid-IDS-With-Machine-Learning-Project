<?php
$logFilePath = '../data/alert';
$items_per_page = 8;
$attack_sessions = [];
if (file_exists($logFilePath)) {
    $lines = file($logFilePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $main_pattern = '/^(\d{2}\/\d{2}-\d{2}:\d{2}:\d{2}).*?\[\*\*\]\s+\[(.*?)\]\s+(.*?)\s+\[\*\*\]\s+.*\{(.*?)\}\s+(.*?):(\d+)\s+->\s+(.*?):(\d+)$/';
        if (preg_match($main_pattern, $line, $matches)) {
            $source_ip = $matches[5] ?? 'N/A'; $dest_ip = $matches[7] ?? 'N/A';
            $signature = trim($matches[2] ?? 'N/A'); $message = trim($matches[3] ?? 'No Message');
            $key = "{$source_ip}-{$dest_ip}-{$signature}";
            $timestamp_str = date("Y")."/".str_replace("-", " ", $matches[1]);
            $timestamp = strtotime($timestamp_str);
            if (!isset($attack_sessions[$key])) {
                $attack_sessions[$key] = [
                    'source_ip' => $source_ip, 'destination_ip' => $dest_ip,
                    'signature' => $signature, 'message' => $message,
                    'event_count' => 1, 'start_time' => $timestamp, 'end_time' => $timestamp
                ];
            } else {
                $attack_sessions[$key]['event_count']++;
                if ($timestamp < $attack_sessions[$key]['start_time']) { $attack_sessions[$key]['start_time'] = $timestamp; }
                if ($timestamp > $attack_sessions[$key]['end_time']) { $attack_sessions[$key]['end_time'] = $timestamp; }
            }
        }
    }
}
$output_sessions = array_values(array_map(function($session) {
    $session['start_time'] = date('Y-m-d H:i:s', $session['start_time']);
    $session['end_time'] = date('Y-m-d H:i:s', $session['end_time']);
    return $session;
}, $attack_sessions));
usort($output_sessions, function($a, $b) {
    return strtotime($b['end_time']) - strtotime($a['end_time']);
});

if (isset($_GET['all'])) {
    header('Content-Type: application/json');
    echo json_encode(['sessions' => $output_sessions]);
    exit();
}

$total_items = count($output_sessions);
$total_pages = ceil($total_items / $items_per_page);
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $items_per_page;
$page_sessions = array_slice($output_sessions, $offset, $items_per_page);
$response = [
    'total_pages' => $total_pages, 'current_page' => $current_page, 'sessions' => $page_sessions
];
header('Content-Type: application/json');
echo json_encode($response);
?>
