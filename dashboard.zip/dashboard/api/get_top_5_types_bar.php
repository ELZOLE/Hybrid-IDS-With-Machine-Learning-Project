<?php
header('Content-Type: application/json');

$mlLogPath = '../data/alerts.jsonl';
$snortLogPath = '../data/alert';


$alert_counts = [];

// --- NEW: �ѧ��ѹ����Ѻ�Ѵ����� Alert ---
function getNormalizedType($message) {
    $message = strtolower($message);

    // --- EDIT: ��Ѻ�ӴѺ����� ��� WebService ��鹡�͹ ---
    if (strpos($message, 'webservice') !== false) {
        return 'Web Service Attack';
    }
    if (strpos($message, 'dos') !== false || strpos($message, 'flooding') !== false) {
        return 'Denial of Service (DoS)';
    }
    // --- END EDIT ---

    if (strpos($message, 'scan') !== false) {
        return 'Network Scan';
    }
    if (strpos($message, 'bad-traffic') !== false) {
        return 'Bad Traffic';
    }
    if (strpos($message, 'ssh-undesirable') !== false) {
        return 'Ssh-undesirable';
    }
    if (strpos($message, 'ml-warning') !== false) {
        return 'ML-General Warning';
    }
    
    $parts = explode(' ', $message);
    $short_msg = implode(' ', array_slice($parts, 0, 3));
    return ucwords($short_msg);
}
// --- END NEW ---

// Process ML Alerts
if (file_exists($mlLogPath)) {
    $handle = fopen($mlLogPath, "r");
    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $log = json_decode(trim($line), true);
            if (is_array($log) && isset($log['category'])) {
                $normalized_type = getNormalizedType($log['category']); // <-- ��ѧ��ѹ����
                if (!isset($alert_counts[$normalized_type])) {
                    $alert_counts[$normalized_type] = 0;
                }
                $alert_counts[$normalized_type]++;
            }
        }
        fclose($handle);
    }
}

// Process Snort Alerts
if (file_exists($snortLogPath)) {
    $lines = file($snortLogPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (preg_match('/\[\*\*\] \[.+\] (.+?) \[\*\*\]/', $line, $matches)) {
            $msg = $matches[1];
            $normalized_type = getNormalizedType($msg); // <-- ��ѧ��ѹ����
            if (!isset($alert_counts[$normalized_type])) {
                $alert_counts[$normalized_type] = 0;
            }
            $alert_counts[$normalized_type]++;
        }
    }
}

// Sort and get top 5
arsort($alert_counts);
$top_5_alerts = array_slice($alert_counts, 0, 5, true);

$labels = array_keys($top_5_alerts);
$data = array_values($top_5_alerts);

echo json_encode(['labels' => $labels, 'data' => $data]);
?>

