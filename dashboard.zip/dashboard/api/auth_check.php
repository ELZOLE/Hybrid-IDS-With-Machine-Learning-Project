<?php
// สร้าง/เรียกใช้ session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ตรวจสอบว่ามี session 'loggedin' หรือไม่
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // หากไม่มี ให้ redirect ไปยังหน้า login.php เสมอ
    // ใช้ "absolute path" เพื่อความแน่นอน
    header('Location: /dashboard/login.php');
    exit;
}
?>
