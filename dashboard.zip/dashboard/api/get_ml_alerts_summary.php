<?php
$logFilePath = '../data/alerts.jsonl';

$items_per_page = 6;
$attack_sessions = [];
if (file_exists($logFilePath)) {
    $handle = fopen($logFilePath, 'r');
    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $log = json_decode(trim($line), true);
            if (is_array($log)) {
                $key = ($log['src_ip'] ?? 'N/A') . '-' . ($log['dst_ip'] ?? 'N/A') . '-' . ($log['category'] ?? 'N/A');
                $timestamp = strtotime($log['timestamp'] ?? 'now');
                if (!isset($attack_sessions[$key])) {
                    $attack_sessions[$key] = [
                        'source_ip' => $log['src_ip'] ?? 'N/A', 'destination_ip' => $log['dst_ip'] ?? 'N/A',
                        'message' => $log['msg'] ?? 'No message', 'category' => $log['category'] ?? 'UNKNOWN',
                        'event_count' => 1, 'start_time' => $timestamp, 'end_time' => $timestamp
                    ];
                } else {
                    $attack_sessions[$key]['event_count']++;
                    if ($timestamp < $attack_sessions[$key]['start_time']) { $attack_sessions[$key]['start_time'] = $timestamp; }
                    if ($timestamp > $attack_sessions[$key]['end_time']) { $attack_sessions[$key]['end_time'] = $timestamp; }
                }
            }
        }
        fclose($handle);
    }
}
$output_sessions = array_values(array_map(function($session) {
    $session['start_time'] = date('Y-m-d H:i:s', $session['start_time']);
    $session['end_time'] = date('Y-m-d H:i:s', $session['end_time']);
    return $session;
}, $attack_sessions));
usort($output_sessions, function($a, $b) {
    return strtotime($b['end_time']) - strtotime($a['end_time']);
});

if (isset($_GET['all'])) {
    header('Content-Type: application/json');
    echo json_encode(['sessions' => $output_sessions]);
    exit();
}

$total_items = count($output_sessions);
$total_pages = ceil($total_items / $items_per_page);
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $items_per_page;
$page_sessions = array_slice($output_sessions, $offset, $items_per_page);
$response = [
    'total_pages' => $total_pages, 'current_page' => $current_page, 'sessions' => $page_sessions
];
header('Content-Type: application/json');
echo json_encode($response);
?>
