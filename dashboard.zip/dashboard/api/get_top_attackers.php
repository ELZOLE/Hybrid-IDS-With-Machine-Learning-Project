<?php
$mlLogPath = '../data/alerts.jsonl';
$snortLogPath = '../data/alert';
$attackers = [];

// Process ML Logs
if (file_exists($mlLogPath)) {
    $handle = fopen($mlLogPath, 'r');
    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $log = json_decode(trim($line), true);
            if (is_array($log) && isset($log['src_ip'])) {
                $src_ip = $log['src_ip'];
                if (!isset($attackers[$src_ip])) {
                    $attackers[$src_ip] = ['ip' => $src_ip, 'ml_count' => 0, 'snort_count' => 0];
                }
                $attackers[$src_ip]['ml_count']++;
            }
        }
        fclose($handle);
    }
}

// Process Snort Logs
if (file_exists($snortLogPath)) {
    $lines = file($snortLogPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $pattern = '/\{(.*?)\}\s+(.*?):(\d+)\s+->\s+(.*?):(\d+)$/';
        if (preg_match($pattern, $line, $matches)) {
            $src_ip = trim($matches[2]);
            if (!isset($attackers[$src_ip])) {
                $attackers[$src_ip] = ['ip' => $src_ip, 'ml_count' => 0, 'snort_count' => 0];
            }
            $attackers[$src_ip]['snort_count']++;
        }
    }
}

// Calculate total and sort
foreach ($attackers as &$attacker) {
    $attacker['total_count'] = $attacker['ml_count'] + $attacker['snort_count'];
}

usort($attackers, function($a, $b) {
    return $b['total_count'] - $a['total_count'];
});

$top_attackers = array_slice($attackers, 0, 10);

header('Content-Type: application/json');
echo json_encode($top_attackers);
?>
