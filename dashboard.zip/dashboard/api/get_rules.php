<?php
$rulesFilePath = '../data/local.rules';
$items_per_page = 10;
$all_rules = [];

if (file_exists($rulesFilePath)) {
    $lines = file($rulesFilePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (empty($line) || $line[0] === '#') {
            continue;
        }
        
        $pattern = '/^(\w+)\s+(\w+)\s+(.*?)\s+(->)\s+(.*?)\s+\((.*)\)/';
        if (preg_match($pattern, $line, $matches)) {
            $source_parts = preg_split('/\s+/', $matches[3]);
            $dest_parts = preg_split('/\s+/', $matches[5]);
            
            $sid = '';
            if (preg_match('/sid:(\d+);/', $matches[6], $sid_match)) {
                $sid = $sid_match[1];
            }

            $msg = '';
            if (preg_match('/msg:"(.*?)"/', $matches[6], $msg_match)) {
                $msg = $msg_match[1];
            }
            
            $all_rules[] = [
                "SID" => $sid,
                "ACTION" => $matches[1],
                "PROTOCOL" => $matches[2],
                "SOURCE IP" => implode(' ', array_slice($source_parts, 0, -1)),
                "SOURCE PORT" => end($source_parts),
                "DIRECTION" => "->",
                "DESTINATION IP" => implode(' ', array_slice($dest_parts, 0, -1)),
                "DEST. PORT" => end($dest_parts),
                "MESSAGE" => $msg,
                "STATUS" => "Active"
            ];
        }
    }
}

if (isset($_GET['all'])) {
    header('Content-Type: application/json');
    echo json_encode(['rules' => $all_rules]);
    exit();
}

$total_items = count($all_rules);
$total_pages = ceil($total_items / $items_per_page);
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $items_per_page;
$page_rules = array_slice($all_rules, $offset, $items_per_page);

$response = [
    'total_pages' => $total_pages,
    'current_page' => $current_page,
    'rules' => $page_rules
];

header('Content-Type: application/json');
echo json_encode($response);
?>
