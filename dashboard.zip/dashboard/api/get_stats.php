<?php
$mlLogPath = '../data/alerts.jsonl';
$snortLogPath = '../data/alert';
$total_alerts = 0;
$unique_ips = [];

if (file_exists($mlLogPath)) {
    $lines = file($mlLogPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $total_alerts += count($lines);
    foreach ($lines as $line) {
        $log = json_decode(trim($line), true);
        if (is_array($log) && isset($log['src_ip'])) {
            $unique_ips[] = $log['src_ip'];
        }
    }
}

if (file_exists($snortLogPath)) {
    $lines = file($snortLogPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $total_alerts += count($lines);
    foreach ($lines as $line) {
        $pattern = '/\{(.*?)\}\s+(.*?):(\d+)\s+->/';
        if (preg_match($pattern, $line, $matches)) {
            if (isset($matches[2])) {
                $unique_ips[] = trim($matches[2]);
            }
        }
    }
}

$stats = [
    'total_alerts' => $total_alerts,
    'unique_attackers' => count(array_unique($unique_ips))
];

header('Content-Type: application/json');
echo json_encode($stats);
?>
