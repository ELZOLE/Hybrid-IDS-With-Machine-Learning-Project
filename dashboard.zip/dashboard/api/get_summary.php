<?php
$mlLogPath = '../data/alerts.jsonl';
$snortLogPath = '../data/alert';
$ml_total = 0;
$snort_total = 0;

if (file_exists($mlLogPath)) {
    $lines = file($mlLogPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $ml_total = count($lines);
}

if (file_exists($snortLogPath)) {
    $lines = file($snortLogPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $snort_total = count($lines);
}

$summary_data = [
    'ml_total' => $ml_total,
    'snort_total' => $snort_total
];

header('Content-Type: application/json');
echo json_encode($summary_data);
?>
