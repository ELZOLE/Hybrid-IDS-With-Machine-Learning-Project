<?php
header('Content-Type: application/json');

$blockedListFile = '../data/blocked_ips.txt';
$response = ['status' => 'error', 'message' => 'Invalid request'];

// Action: Get current blocked IPs (ยังทำงานเหมือนเดิม)
if (isset($_GET['action']) && $_GET['action'] === 'get_status') {
    if (file_exists($blockedListFile)) {
        // ใช้ array_unique เพื่อกำจัด IP ที่ซ้ำกัน
        $blocked_ips = array_unique(file($blockedListFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));
        $response = ['status' => 'success', 'blocked_ips' => array_values($blocked_ips)];
    } else {
        $response = ['status' => 'success', 'blocked_ips' => []];
    }
}

// Action: Execute block/unblock in real-time
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['action']) && isset($data['ip'])) {
        $action = strtolower($data['action']); // "block" or "unblock"
        $ip = $data['ip'];

        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            if ($action === 'block' || $action === 'unblock') {
                // ใช้ escapeshellarg เพื่อป้องกัน Command Injection ซึ่งเป็นช่องโหว่ร้ายแรง
                $safe_action = escapeshellarg($action);
                $safe_ip = escapeshellarg($ip);

                // สร้างคำสั่งเพื่อรัน Helper Script ผ่าน sudo
                $command = "sudo /usr/local/bin/manage_firewall.sh $safe_action $safe_ip 2>&1";

                // รันคำสั่งและเก็บผลลัพธ์
                exec($command, $output, $return_var);

                if ($return_var === 0) {
                    $response = ['status' => 'success', 'message' => implode("\n", $output)];
                } else {
                    $response['message'] = "Execution failed with error code $return_var: " . implode("\n", $output);
                }
            }
        } else {
            $response['message'] = 'Invalid IP address format.';
        }
    }
}

echo json_encode($response);
?>
