<?php include 'api/auth_check.php'; ?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>IDS Dashboard - Snort Alerts Summary</title>
    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
</head>
<body>
    <aside class="sidebar">
        <h1>IDS</h1>
        <nav>
            <a href="index.php">Overview</a>
            <a href="alerts.php">Alert ML</a>
            <a href="snort_alerts.php" class="active">Alert Snort</a>
            <a href="rules.php">Rules</a>
            <a href="#" id="logout-btn" style="margin-top: 20px;">Logout</a>
        </nav>
    </aside>
    <main class="content">
        <div class="card" style="overflow-x: auto;">
            <h2>Snort Alerts Summary</h2>
            <p>Summary of attack events detected by Snort rules.</p>
            <table>
                <thead>
                    <tr>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>ID</th>
                        <th>Source IP</th>
                        <th>Destination IP</th>
                        <th>Category</th>
                        <th>Event Count</th>
                    </tr>
                </thead>
                <tbody id="snort-alerts-table"></tbody>
            </table>
            <div id="pagination-controls" style="text-align: center; margin-top: 20px;"></div>
        </div>
    </main>
    <script src="js/snort_alerts.js"></script>

    <script>
    document.getElementById('logout-btn').addEventListener('click', function(e) {
        e.preventDefault(); // Prevent the link from navigating immediately
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to log out?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'api/logout.php'; // Redirect to logout script if confirmed
            }
        });
    });
    </script>
</body>
</html>
